FollowTrackConstraint(Constraint)
=================================

.. currentmodule:: bpy.types

base classes --- :class:`bpy_struct`, :class:`Constraint`


.. class:: FollowTrackConstraint(Constraint)

   Lock motion to the target motion track

   .. attribute:: camera

      Camera to which motion is parented (if empty active scene camera is used)

      :type: :class:`Object` | None

   .. attribute:: clip

      Movie Clip to get tracking data from

      :type: :class:`MovieClip` | None

   .. attribute:: depth_object

      Object used to define depth in camera space by projecting onto surface of this object

      :type: :class:`Object` | None

   .. attribute:: frame_method

      How the footage fits in the camera frame (default ``'STRETCH'``)

      :type: Literal['STRETCH', 'FIT', 'CROP']

   .. attribute:: object

      Movie tracking object to follow (if empty, camera object is used) (default "", never None)

      :type: str

   .. attribute:: track

      Movie tracking track to follow (default "", never None)

      :type: str

   .. attribute:: use_3d_position

      Use 3D position of track to parent to (default False)

      :type: bool

   .. attribute:: use_active_clip

      Use active clip defined in scene (default False)

      :type: bool

   .. attribute:: use_undistorted_position

      Parent to undistorted position of 2D track (default False)

      :type: bool

   .. classmethod:: bl_rna_get_subclass(id, default=None, /)
   
      :param id: The RNA type identifier.
      :type id: str
      :param default: The value to return when not found.
      :type default: :class:`bpy.types.Struct` | None
      :return: The RNA type or default when not found.
      :rtype: :class:`bpy.types.Struct`


   .. classmethod:: bl_rna_get_subclass_py(id, default=None, /)
   
      :param id: The RNA type identifier.
      :type id: str
      :param default: The value to return when not found.
      :type default: type | None
      :return: The class or default when not found.
      :rtype: type


Inherited Properties
--------------------

.. hlist::
   :columns: 2

   - :class:`bpy_struct.id_data`
   - :class:`Constraint.name`
   - :class:`Constraint.type`
   - :class:`Constraint.is_override_data`
   - :class:`Constraint.owner_space`
   - :class:`Constraint.target_space`
   - :class:`Constraint.space_object`
   - :class:`Constraint.space_subtarget`
   - :class:`Constraint.mute`
   - :class:`Constraint.enabled`
   - :class:`Constraint.show_expanded`
   - :class:`Constraint.is_valid`
   - :class:`Constraint.active`
   - :class:`Constraint.influence`
   - :class:`Constraint.error_location`
   - :class:`Constraint.error_rotation`

Inherited Functions
-------------------

.. hlist::
   :columns: 2

   - :class:`bpy_struct.as_pointer`
   - :class:`bpy_struct.driver_add`
   - :class:`bpy_struct.driver_remove`
   - :class:`bpy_struct.get`
   - :class:`bpy_struct.id_properties_clear`
   - :class:`bpy_struct.id_properties_ensure`
   - :class:`bpy_struct.id_properties_ui`
   - :class:`bpy_struct.is_property_hidden`
   - :class:`bpy_struct.is_property_overridable_library`
   - :class:`bpy_struct.is_property_readonly`
   - :class:`bpy_struct.is_property_set`
   - :class:`bpy_struct.items`
   - :class:`bpy_struct.keyframe_delete`
   - :class:`bpy_struct.keyframe_insert`
   - :class:`bpy_struct.keys`
   - :class:`bpy_struct.path_from_id`
   - :class:`bpy_struct.path_from_module`
   - :class:`bpy_struct.path_resolve`
   - :class:`bpy_struct.pop`
   - :class:`bpy_struct.property_overridable_library_set`
   - :class:`bpy_struct.property_unset`
   - :class:`bpy_struct.rna_ancestors`
   - :class:`bpy_struct.type_recast`
   - :class:`bpy_struct.values`
   - :class:`Constraint.bl_rna_get_subclass`
   - :class:`Constraint.bl_rna_get_subclass_py`

